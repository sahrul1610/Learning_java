package interfaces;

public interface CalculatePrice {
    public abstract void calculatePrice();
}

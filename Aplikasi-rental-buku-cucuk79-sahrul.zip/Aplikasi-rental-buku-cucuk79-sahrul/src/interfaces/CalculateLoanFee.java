package interfaces;

public interface CalculateLoanFee {
    public abstract void calculateLoanFee();
    
} 
